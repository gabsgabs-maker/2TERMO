const readline = require('readline-sync');
const { verificarPeso } = require('./funcoesBalanca');

console.log("=== SISTEMA DE BALANÇA DE PRECISÃO INDUSTRIAL ===");

while (true) {
  try {

    const entrada = readline.question('\nDigite o peso da peça em gramas (ou "sair" para encerrar): ');

  
    if (entrada.toLowerCase() === 'sair') {
      console.log('Encerrando o sistema da balança. Até logo!');
      break;
    }
    const resultado = verificarPeso(entrada);
    console.log(`✅ ${resultado}`);

} catch (erro) {
    console.log(`⚠️  ALERTA: ${erro.message}`);
  }
}