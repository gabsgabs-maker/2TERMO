const entrada = require("readline-sync")
const cinema = [
    { titulo : "Coraline", censura:0 },
    { titulo : "Deadpool", censura: 18 },
    { titulo : "Batman", censura: 12 } 
];
const idadeUser = entrada.questionInt("Qual a sua idade?: ");
for (let i = 0; i < cinema.length; i++) {
    if (idadeUser >= cinema [i].censura) {
        console.log(`Pode assistir: ${cinema [i].titulo}`);
    } 
}


