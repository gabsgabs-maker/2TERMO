const entrada = require('readline-sync');

const  valor_total = entrada.questionFloat("Qual o valor total do produto: ");
const  quantidade_parcelas = entrada.questionFloat("Qual a quantidade de parcelas: ");
const valor_por_mes = valor_total/ quantidade_parcelas;

if(quantidade_parcelas <=12){

for (let i = 0; i  < quantidade_parcelas; i++){
    console.log(`${quantidade_parcelas[i+1]}: valor por parcela R${valor_por_mes}`);
}

}else{
    console.log(`A quantidade de parcelas passou do nivel maximo`)
}