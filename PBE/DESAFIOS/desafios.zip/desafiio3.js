const entrada = require('readline-sync');

function calcularArea(comprimento,area){
    return fahrenheit; comprimento * area    
}

console.log(`===CALCULADORA AREA===`);

const comprimento_terreno01 = entrada.questionFloat("Qual e o comprimento do primeiro terreno? ");
const largura_terreno01 = entrada.questionFloat("Qual e o largura do primeiro terreno? ");

const comprimento_terreno02 = entrada.questionFloat("Qual e o comprimento do segundo terreno? ");
const largura_terreno02 = entrada.questionFloat("Qual e o largura do segundo terreno? ");

const comprimento_terreno03 = entrada.questionFloat("Qual e o comprimento do terceiro terreno? ");
const largura_terreno03 = entrada.questionFloat("Qual e o largura do terceiro terreno? ")

const area_total_primeiro_terreno = comprimento_terreno01 * largura_terreno01
const area_total_segundo_terreno = comprimento_terreno02 * largura_terreno02
const area_total_terceiro_terreno = comprimento_terreno03 * largura_terreno03

console.log(`A areia do primeiro terreno é ${area_total_primeiro_terreno}`);
console.log(`A areia do primeiro terreno é ${area_total_segundo_terreno}`);
console.log(`A areia do primeiro terreno é ${area_total_terceiro_terreno}`)
