const entrada = require('readline-sync');

const nome = entrada.question("Informe o nome: ");
const Idade = entrada.questionInt("Informe a idade: ");
const tempo_contribuicao = entrada.questionInt("Tempo de contribuicao da pessoa: ");

if(Idade >=65 && tempo_contribuicao <=30){
    console.log(`\nVocê tem ${Idade}, esta dentro dos  padroes, sua aposentadoria vai ser encaminhada`);
    console.log(`\nVocê tem ${tempo_contribuicao}, de contribuição, esta dentro dos padroes, sua aposentadoria vai ser encaminhada`)
} else{
    console.log(`\n Você tem ${Idade}, não esta dentro dos padores,não continuaremos com sua aposentadoria`);
    console.log(`\n Você tem ${tempo_contribuicao}, não esta dentro dos padroes, não continuaremos com sua aposentadoria`)
}

